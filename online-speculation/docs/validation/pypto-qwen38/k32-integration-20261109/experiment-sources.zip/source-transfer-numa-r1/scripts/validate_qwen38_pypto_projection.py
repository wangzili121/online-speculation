"""交错测量相同 NPU 的本地/远端 NUMA 共享内存上传。"""

import argparse
import json
import os
from pathlib import Path
import statistics
import time


def cpus(value):
    result = set()
    for part in value.split(","):
        a, _, b = part.partition("-")
        result.update(range(int(a), int(b or a) + 1))
    return result


def placement(tensor):
    ptr = tensor.data_ptr()
    for row in Path("/proc/self/maps").read_text().splitlines():
        a, b = [int(x, 16) for x in row.split()[0].split("-")]
        if a <= ptr < b:
            key = hex(a)[2:]
            return next(line for line in Path("/proc/self/numa_maps").read_text().splitlines() if line.split()[0] == key)
    raise RuntimeError("shared allocation missing from process maps")


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--source", type=Path, required=True)
    p.add_argument("--device", type=int, required=True)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--local-cpus", required=True)
    p.add_argument("--remote-cpus", required=True)
    p.add_argument("--expected-physical", required=True)
    a = p.parse_args()
    import torch
    from pypto.backend import BackendType
    from pypto.ir import DistributedConfig
    from pypto.runtime import DistributedWorker, RunConfig, ExecutionMode, ReadOnlyHostTensor
    from blockspec.pypto_qwen38.projection_programs import make_norm
    affinity = os.sched_getaffinity(0)
    groups = {"local": cpus(a.local_cpus), "remote": cpus(a.remote_cpus)}
    if a.output.exists() or any(not x or not x <= affinity for x in groups.values()):
        p.error("new output and allowed CPU sets required")
    if os.environ.get("ASCEND_RT_VISIBLE_DEVICES") != a.expected_physical:
        raise RuntimeError("wrong physical NPU for the supplied CPU topology")
    report = dict(passed=False, physical_device=a.expected_physical, bytes=512 << 20, rounds=30)
    worker = handle = returned = None
    try:
        torch.set_num_threads(1)
        sources = {}
        for i, (name, allowed) in enumerate(groups.items()):
            os.sched_setaffinity(0, allowed)
            sources[name] = torch.empty(report["bytes"], dtype=torch.uint8).share_memory_().fill_(i + 1)
        report["numa_maps"] = {name: placement(x) for name, x in sources.items()}
        os.sched_setaffinity(0, groups["local"])
        returned = torch.empty(report["bytes"], dtype=torch.uint8).share_memory_()
        config = RunConfig(backend_type=BackendType.Ascend910B, execution_mode=ExecutionMode.ONBOARD,
                           distributed_config=DistributedConfig(device_ids=[a.device], num_sub_workers=0))
        meta = lambda shape, dtype: torch.empty(shape, dtype=dtype, device="meta")
        # 仅注册一个小程序以启动 worker；本实验只测 H2D copy，不测 norm。
        program = make_norm(a.source)[1].compile(meta((32, 5120), torch.bfloat16),
            meta((1, 5120), torch.float32), meta((32, 5120), torch.bfloat16), config=config)
        worker = DistributedWorker([program], config=config,
            inherited_host_tensors=[*(ReadOnlyHostTensor(x) for x in sources.values()), returned])
        handle = worker.alloc_tensor((report["bytes"],), torch.uint8)
        for x in sources.values():
            for _ in range(5):
                worker.copy_to(handle.data_ptr, x.data_ptr(), report["bytes"])
        samples = {name: [] for name in sources}
        for step in range(report["rounds"]):
            for name in (list(sources) if step % 2 == 0 else list(reversed(sources))):
                start = time.perf_counter()
                worker.copy_to(handle.data_ptr, sources[name].data_ptr(), report["bytes"])
                samples[name].append(time.perf_counter() - start)
        for name, x in sources.items():
            worker.copy_to(handle.data_ptr, x.data_ptr(), report["bytes"])
            worker.copy_from(returned.data_ptr(), handle.data_ptr, report["bytes"])
            assert torch.equal(x, returned), name
        report["samples_seconds"] = samples
        report["median_seconds"] = {name: statistics.median(values) for name, values in samples.items()}
        report["decimal_GBps"] = {name: report["bytes"] / seconds / 1e9 for name, seconds in report["median_seconds"].items()}
        report["passed"] = True
    except BaseException as error:
        report["error"] = repr(error)
        raise
    finally:
        try:
            if worker is not None:
                if handle is not None:
                    worker.free_tensor(handle)
                worker.close()
        except BaseException as error:
            report.update(passed=False, cleanup_error=repr(error))
            raise
        finally:
            os.sched_setaffinity(0, affinity)
            a.output.write_text(json.dumps(report, indent=2) + "\n")
            print(json.dumps(report), flush=True)


if __name__ == "__main__":
    main()
