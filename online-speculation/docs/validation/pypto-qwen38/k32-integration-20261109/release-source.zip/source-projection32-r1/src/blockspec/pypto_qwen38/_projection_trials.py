"""K32 draft 投影和 input norm 独立候选，保留原生 16+16 对照。"""

from .baseline import native_module


def make_projection(source, inputs, outputs, *, tile=128, native=False):
    if inputs % 512 or outputs % min(tile, outputs) or tile not in {64, 128, 256}:
        raise ValueError("complete 512 input tiles and supported output tiles required")
    import pypto.language as pl
    original = native_module(source, "model").linear_hidden_projection_inline
    N = min(tile, outputs)

    @pl.jit.inline
    def block(hidden: pl.Tensor, weight: pl.Tensor, result: pl.Tensor):
        with pl.spmd(outputs // N, name_hint="orthrus_projection32", optimizations=[pl.cross_core_slot(slot_num=1)]):
            column = pl.tile.get_block_idx() * N
            accumulator = pl.create_tensor([32, N], dtype=pl.FP32)
            for chunk in pl.pipeline(inputs // 512, stage=2):
                start = chunk * 512
                x = pl.slice(hidden, [32, 512], [0, start])
                w = pl.slice(weight, [N, 512], [column, start])
                accumulator = pl.matmul_acc(accumulator, x, w, b_trans=True, init_cond=(chunk == 0))
            result[0:32, column:column + N] = pl.cast(accumulator, pl.BF16, mode="rint")
        return result

    @pl.jit.inline
    def baseline(hidden: pl.Tensor, weight: pl.Tensor, result: pl.Tensor):
        for half in pl.range(2):
            row = half * 16
            x: pl.Tensor[[16, inputs], pl.BF16] = pl.slice(hidden, [16, inputs], [row, 0])
            out = pl.create_tensor([16, outputs], dtype=pl.BF16)
            out = original(x, weight, out)
            result[row:row + 16, 0:outputs] = out
        return result

    implementation = baseline if native else block

    @pl.jit
    def linear(hidden: pl.Tensor, weight: pl.Tensor, result: pl.Out[pl.Tensor]):
        return implementation(hidden, weight, result)

    @pl.jit.host
    def entry(hidden: pl.Tensor, weight: pl.Tensor, result: pl.Out[pl.Tensor]):
        linear(hidden, weight, result, device=0)

    return entry


def make_norm(source, *, row_tile=1, native=False):
    if row_tile not in {1, 2}:
        raise ValueError("row_tile must be 1 or 2")
    import pypto.language as pl
    original = native_module(source, "model").rmsnorm_rmsnorm_inline
    R, D = row_tile, 5120

    @pl.jit.inline
    def block(hidden: pl.Tensor, gamma: pl.Tensor, result: pl.Tensor):
        with pl.spmd(32 // R, name_hint="orthrus_input_norm32"):
            row = pl.tile.get_block_idx() * R
            x = pl.cast(pl.slice(hidden, [R, D], [row, 0]), pl.FP32)
            variance = pl.mul(pl.row_sum(pl.mul(x, x)), 1. / D)
            inverse = pl.rsqrt(pl.add(variance, 1e-6), high_precision=True)
            weight = pl.slice(gamma, [1, D], [0, 0])
            normalized = pl.col_expand_mul(pl.row_expand_mul(x, inverse), weight)
            result[row:row + R, 0:D] = pl.cast(normalized, pl.BF16, mode="rint")
        return result

    @pl.jit.inline
    def baseline(hidden: pl.Tensor, gamma: pl.Tensor, result: pl.Tensor):
        for half in pl.range(2):
            row = half * 16
            x: pl.Tensor[[16, D], pl.BF16] = pl.slice(hidden, [16, D], [row, 0])
            out = pl.create_tensor([16, D], dtype=pl.BF16)
            out = original(x, gamma, out)
            result[row:row + 16, 0:D] = out
        return result

    implementation = baseline if native else block

    @pl.jit
    def norm(hidden: pl.Tensor, gamma: pl.Tensor, result: pl.Out[pl.Tensor]):
        return implementation(hidden, gamma, result)

    @pl.jit.host
    def entry(hidden: pl.Tensor, gamma: pl.Tensor, result: pl.Out[pl.Tensor]):
        norm(hidden, gamma, result, device=0)

    return entry
