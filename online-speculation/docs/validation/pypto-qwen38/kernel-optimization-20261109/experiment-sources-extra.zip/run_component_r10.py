"""在空闲卡上执行有超时和清理的独立算子实验。"""
import argparse
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

ROOT = Path('/data/disk1/wangzili/orthrus-qwen38-pypto-20261105')
sys.path.insert(0, str(ROOT))
from host_runtime import environment, PYTHON, HOME_RUNTIME
sys.path.insert(0, str(ROOT / 'source-r5/scripts'))
from watch_glm53_validation import acquire_devices, idle_devices, release_devices

p = argparse.ArgumentParser()
p.add_argument('--tag', required=True)
p.add_argument('--source', default='source-gdn-r1')
p.add_argument('--task', choices=('gdn', 'attention', 'gdn-model', 'gdn-service', 'gdn-aux', 'gdn-http'), default='gdn')
p.add_argument('--wait-seconds', type=int, default=180)
a, extra = p.parse_known_args()
if any(not s.replace('-', '').isalnum() for s in (a.tag, a.source)):
    p.error('simple source and tag names required')
source = ROOT / a.source
out = ROOT / 'kernels-20261109' / a.tag
if out.exists() or out.with_suffix('.log').exists() or out.with_suffix('.json').exists():
    raise FileExistsError(out)
out.parent.mkdir(exist_ok=True)
locks, deadline = None, time.monotonic() + a.wait_seconds
while locks is None:
    for card in idle_devices(subprocess.check_output(['/usr/local/bin/npu-smi', 'info'], text=True)):
        locks = acquire_devices(Path('/data/disk1/wangzili/orthrus-glm53-flash-20261101'), [card])
        if locks is not None:
            break
    if locks is None:
        if time.monotonic() >= deadline:
            raise TimeoutError('no idle NPU')
        time.sleep(10)
env = environment(card)
env['PYTHONPATH'] = str(source / 'src') + ':' + env['PYTHONPATH']
scripts = {'gdn-model': 'compare_qwen38_pypto_gdn.py', 'gdn-service': 'validate_qwen38_pypto_neural.py', 'gdn-aux': 'validate_qwen38_pypto_gdn_aux.py', 'gdn-http': 'smoke_qwen38_pypto_base.py'}
script = source / 'scripts' / scripts.get(a.task, f'validate_qwen38_pypto_{a.task}.py')
command = [str(PYTHON), str(script), '--device', '0']
command += ['--output-dir', str(out)] if a.task in {'gdn-model', 'gdn-http'} else ['--output', str(out.with_suffix('.json'))]
if a.task != 'attention':
    command += ['--source', str(ROOT / 'OneServing')]
if a.task in {'gdn-model', 'gdn-service', 'gdn-http'}:
    command += ['--model', '/data/disk/wangzili/models/Qwen3.8-27B', '--head-dir', str(ROOT / 'heads/trained-v4')]
if a.task == 'gdn-service':
    command += ['--tokens', '3', '--audit-block']
if a.task in {'gdn-service', 'gdn-http'}:
    for flag, value in (('--attention-backend','paged'), ('--gdn-backend','vector'), ('--draft-group-size','4')):
        if flag not in extra:
            command += [flag, value]
command += extra
process = None
report = dict(passed=False, physical_device=card, command=command)
try:
    with out.with_suffix('.log').open('xb') as log:
        process = subprocess.Popen(command, env=env, cwd=HOME_RUNTIME / 'work',
            stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        report['pid'] = process.pid
        out.with_suffix('.supervisor.json').write_text(json.dumps(report, indent=2))
        print(json.dumps(report), flush=True)
        report['returncode'] = process.wait(timeout=1800 if a.task.startswith('gdn-') else 1200)
        report['passed'] = report['returncode'] == 0
finally:
    if process is not None and process.poll() is None:
        os.killpg(process.pid, signal.SIGINT)
        try:
            process.wait(timeout=20)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait(timeout=20)
    release_devices(locks)
    out.with_suffix('.supervisor.json').write_text(json.dumps(report, indent=2))
print(json.dumps(report), flush=True)
raise SystemExit(0 if report['passed'] else 1)
