"""双 query-head 共用一份分页 K/V 的调优候选，保持现有数学与舍入。"""

def make_grouped_fixed_attention(shape, *, physical_pages, pool_layers, capacity):
    import pypto.language as pl

    K, HQ, HK, D = shape.block_size, shape.q_heads, shape.kv_heads, shape.head_dim
    M, C, PAGE = shape.query_tile, capacity, shape.page_size
    SPAN = 64 if M == 32 else 128
    ROWS = pool_layers * HK * physical_pages * PAGE
    G, MT = 2, M * 2
    SLOTS = 1

    @pl.jit.inline
    def gather(pool: pl.Tensor, block: pl.Tensor, zero: pl.Tensor, table: pl.Tensor,
               layer: pl.Scalar[pl.INT32], head: pl.Scalar[pl.INT32],
               past: pl.Scalar[pl.INT32], width: pl.Scalar[pl.INT32], start: pl.Scalar[pl.INT32]):
        local = pl.create_l1([SPAN, D], pl.BF16)
        local = pl.gather_row(local, zero, [0, 0], [0, 0], [SPAN, D])
        # 每次只搬同一物理页的有效连续行；末页尾部和 inactive MASK 行不读。
        for page in pl.range(SPAN // PAGE):
            begin = start + page * PAGE
            if begin < past:
                count = pl.min(PAGE, past - begin)
                physical = pl.read(table, [begin // PAGE])
                source = ((layer * HK + head) * physical_pages + physical) * PAGE
                local = pl.gather_row(local, pool, [page * PAGE, 0], [source, 0], [PAGE, D],
                                      valid_shape=[count, D])
            lo = pl.max(begin, past)
            hi = pl.min(begin + PAGE, past + width)
            if hi > lo:
                local = pl.gather_row(local, block, [lo - start, 0], [lo - past, head * D], [PAGE, D],
                                      valid_shape=[hi - lo, D])
        return local

    @pl.jit.inline
    def scores(query: pl.Tensor, block: pl.Tensor, pool: pl.Tensor, zero: pl.Tensor,
               table: pl.Tensor, bias: pl.Tensor, layer: pl.Scalar[pl.INT32], head: pl.Scalar[pl.INT32],
               past: pl.Scalar[pl.INT32], width: pl.Scalar[pl.INT32], start: pl.Scalar[pl.INT32], qrow: pl.Scalar[pl.INT32], qhead: pl.Scalar[pl.INT32]):
        raw = pl.slice(query, [M, G * D], [qrow, qhead * D])
        compact = pl.cast(pl.cast(raw, pl.FP32), pl.BF16, mode="rint")
        q = pl.reshape(compact, [MT, D])
        keys = gather(pool, block, zero, table, layer, head, past, width, start)
        product = pl.matmul(q, keys, b_trans=True, out_dtype=pl.FP32)
        rounded = pl.cast(product, pl.BF16, mode="rint")
        scaled = pl.cast(pl.mul(pl.cast(rounded, pl.FP32), D ** -.5), pl.BF16, mode="rint")
        result = pl.col_expand_add(pl.cast(scaled, pl.FP32), pl.slice(bias, [1, SPAN], [0, start]))
        return result

    @pl.jit.inline
    def pair(query: pl.Tensor, block: pl.Tensor, pool: pl.Tensor, zero: pl.Tensor,
             table: pl.Tensor, bias: pl.Tensor, layer: pl.Scalar[pl.INT32], head: pl.Scalar[pl.INT32],
             past: pl.Scalar[pl.INT32], width: pl.Scalar[pl.INT32], start: pl.Scalar[pl.INT32], qrow: pl.Scalar[pl.INT32], qhead: pl.Scalar[pl.INT32]):
        first = scores(query, block, pool, zero, table, bias, layer, head, past, width, start, qrow, qhead)
        second = scores(query, block, pool, zero, table, bias, layer, head, past, width, start + SPAN, qrow, qhead)
        return pl.concat(first, second)

    @pl.jit.inline
    def quad(query: pl.Tensor, block: pl.Tensor, pool: pl.Tensor, zero: pl.Tensor,
             table: pl.Tensor, bias: pl.Tensor, layer: pl.Scalar[pl.INT32], head: pl.Scalar[pl.INT32],
             past: pl.Scalar[pl.INT32], width: pl.Scalar[pl.INT32], start: pl.Scalar[pl.INT32], qrow: pl.Scalar[pl.INT32], qhead: pl.Scalar[pl.INT32]):
        first = pair(query, block, pool, zero, table, bias, layer, head, past, width, start, qrow, qhead)
        second = pair(query, block, pool, zero, table, bias, layer, head, past, width, start + 2 * SPAN, qrow, qhead)
        return pl.concat(first, second)

    @pl.jit.inline
    def octet(query: pl.Tensor, block: pl.Tensor, pool: pl.Tensor, zero: pl.Tensor,
              table: pl.Tensor, bias: pl.Tensor, layer: pl.Scalar[pl.INT32], head: pl.Scalar[pl.INT32],
              past: pl.Scalar[pl.INT32], width: pl.Scalar[pl.INT32], start: pl.Scalar[pl.INT32], qrow: pl.Scalar[pl.INT32], qhead: pl.Scalar[pl.INT32]):
        first = quad(query, block, pool, zero, table, bias, layer, head, past, width, start, qrow, qhead)
        second = quad(query, block, pool, zero, table, bias, layer, head, past, width, start + 4 * SPAN, qrow, qhead)
        return pl.concat(first, second)

    score_kernel = scores if C // SPAN == 1 else pair if C // SPAN == 2 else quad if C // SPAN == 4 else octet

    @pl.jit.inline
    def paged(query: pl.Tensor, key: pl.Tensor, value: pl.Tensor, gate: pl.Tensor,
              key_pool: pl.Tensor, value_pool: pl.Tensor, table: pl.Tensor, bias: pl.Tensor,
              output: pl.Tensor, past: pl.Scalar[pl.INT32], width: pl.Scalar[pl.INT32],
              layer: pl.Scalar[pl.INT32]):
        key_flat = pl.reshape(key_pool, [ROWS, D])
        value_flat = pl.reshape(value_pool, [ROWS, D])
        zero = pl.create_tensor([SPAN, D], dtype=pl.BF16)
        with pl.spmd(1, name_hint="orthrus_l1_zero_source"):
            zero_row = pl.tile.get_block_idx() * SPAN
            zero[zero_row:zero_row + SPAN, 0:D] = pl.full([SPAN, D], dtype=pl.BF16, value=0.)
        with pl.spmd(HQ // G * (K // M), name_hint="orthrus_direct_paged_attention",
                     optimizations=[pl.cross_core_slot(slot_num=SLOTS)]):
            task = pl.tile.get_block_idx()
            head, row = task // (K // M) * G, task % (K // M) * M
            kv = head // (HQ // HK)
            score = score_kernel(query, key, key_flat, zero, table, bias, layer, kv, past, width, 0, row, head)
            exponential = pl.exp(pl.row_expand_sub(score, pl.row_max(score)))
            probability = pl.cast(pl.row_expand_div(exponential, pl.row_sum(exponential)), pl.BF16, mode="rint")
            total = pl.create_tensor([MT, D], dtype=pl.FP32)
            # 先保持固定区间累加，避免跨 Cube/Vector 的条件输出携带状态。
            for part in pl.range(C // SPAN):
                start = part * SPAN
                values = gather(value_flat, value, zero, table, layer, kv, past, width, start)
                p = pl.slice(probability, [MT, SPAN], [0, start])
                total = pl.matmul_acc(total, p, values, init_cond=(part == 0))
            attended = pl.cast(total, pl.BF16, mode="rint")
            compact_output = pl.reshape(attended, [M, G * D])
            for member in pl.range(G):
                actual_head = head + member
                raw_gate = pl.cast(pl.slice(gate, [M, D], [row, actual_head * D]), pl.FP32)
                sigmoid = pl.cast(pl.recip(pl.add(pl.exp(pl.neg(raw_gate)), 1.)), pl.BF16, mode="rint")
                selected = pl.slice(compact_output, [M, D], [0, member * D])
                output[row:row + M, actual_head * D:(actual_head + 1) * D] = pl.cast(
                    pl.mul(pl.cast(selected, pl.FP32), pl.cast(sigmoid, pl.FP32)), pl.BF16, mode="rint")
        return output

    @pl.jit
    def attention(query: pl.Tensor, key: pl.Tensor, value: pl.Tensor, gate: pl.Tensor,
                  key_pool: pl.Tensor, value_pool: pl.Tensor, table: pl.Tensor, bias: pl.Tensor,
                  output: pl.Out[pl.Tensor], past: pl.Scalar[pl.INT32], width: pl.Scalar[pl.INT32],
                  layer: pl.Scalar[pl.INT32]):
        return paged(query, key, value, gate, key_pool, value_pool, table, bias, output, past, width, layer)

    @pl.jit.host
    def entry(query: pl.Tensor, key: pl.Tensor, value: pl.Tensor, gate: pl.Tensor,
              key_pool: pl.Tensor, value_pool: pl.Tensor, table: pl.Tensor, bias: pl.Tensor,
              output: pl.Out[pl.Tensor], past: pl.Scalar[pl.INT32], width: pl.Scalar[pl.INT32],
              layer: pl.Scalar[pl.INT32]):
        attention(query, key, value, gate, key_pool, value_pool, table, bias, output, past, width, layer, device=0)

    return paged, entry

